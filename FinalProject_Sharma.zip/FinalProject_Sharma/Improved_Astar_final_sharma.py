# -*- coding: utf-8 -*-
"""
Created on Sun May  9 10:35:25 2021

@author: sharm
"""



import cv2
import math
import heapq
import numpy as np

from datetime import datetime

robot_world = cv2.imread('new_map.png')

start_time = datetime.now() # To calculate time

# Start and end point
initial_coordinate = (50, 50) # 80, 30
#Change Line 3 and 4 in launch file to reflect this but divide by 100 for values 
final_coordinate = (100, 100)# 170,130
print('The Initial location of the (center of the) robot is:', initial_coordinate)
print('The Goal location of the (center of the) robot is:', final_coordinate)

initial_center = (initial_coordinate[0], initial_coordinate[1])
final_center = (final_coordinate[0], final_coordinate[1])
radius = 10.0
clearance = 5.0
circlePoints = []
step_size = 10
initial_orientation = 0
circlePoints = []

# Data for improved A star
aplha = 100
beta = 0.5

start_time = datetime.now() # To calculate time

# Calculate Distance between two points
def dist(p1, p2):
    return math.sqrt((p1[0] - p2[0]) * (p1[0] - p2[0]) + (p1[1] - p2[1]) * (p1[1] - p2[1]))

# to get the points at the circumference
def getPoints(center):
    print('center', center)
    circlePoints = []
    for i in range(0, 164):
        for j in range(0, 240):
            d = dist((j, i), center)
            if d <= radius + clearance and d > radius + clearance - 1:
                circlePoints.append((j,i))
    #print('total points', len(circlePoints))
    
    return circlePoints
   
# To check if the move should be made
def isSafe(center_x, center_y):
    if center_x<15 or center_y<15 or center_x>225 or center_y>149:
        return False
    else:
        points = getPoints((center_x, center_y))
        for point in points:
            nx = point[0] 
            ny = point[1] 

            if nx < 0 or ny < 0 or ny >= 164 or nx >= 240:
                return False
            if np.all(robot_world[ny,nx] == [0, 0, 0]): #).any():
                #print('fail2', ny, nx, robot_world[ny,nx])
                return False
        else:
            #print('pass pass')
            return True


def Round2Point5(num):
    return int(round(num * 2) / 2)

def RoundTo15(x, base=15):
    return int(base * round(x / base))
        
        
# Functions for) movements   
def move_180(cnode): #cc, orientation): 
    start_x = cnode.config[0]
    start_y = cnode.config[1]
    orientation = cnode.angle
    #h = cnode.h
    ng = cnode.g + 2 * math.sqrt(2)
    
    start_rad_orientation = (orientation * math.pi)/180
    start_rad_orientation_step = 45 #15
    rad_orientation = start_rad_orientation + (start_rad_orientation_step*4*math.pi)/180

    dx = math.cos(rad_orientation)*step_size 
    dy = math.sin(rad_orientation)*step_size 
    new_x = Round2Point5(start_x + dx)
    new_y = Round2Point5(start_y + dy)

    new_angle_deg = rad_orientation*180/math.pi
    if new_angle_deg > 360:
        new_angle_deg = RoundTo15(abs(new_angle_deg - 360))
        
    new_node = Node((new_x, new_y), new_angle_deg, 0, 0 , 0)
    #curr_node = [(cnode.config[0],cnode.config[1]), cnode.angle, cnode.g, cnode.h, cnode.f]

    #print('move_180 node', new_node.config)
    if isSafe(new_x, new_y) == True: 
        return new_node
    else:
        return None
    
   
def move_135(cnode): #c, orientation):
    start_x = cnode.config[0]
    start_y = cnode.config[1]
    orientation = cnode.angle
    #h = cnode.h
    ng = cnode.g + 2 
    
    start_rad_orientation = (orientation * math.pi)/180
    start_rad_orientation_step = 45 #15
    rad_orientation = start_rad_orientation + (start_rad_orientation_step*3*math.pi)/180

    dx = math.cos(rad_orientation)*step_size 
    dy = math.sin(rad_orientation)*step_size 
    new_x = Round2Point5(start_x + dx)
    new_y = Round2Point5(start_y + dy)

    new_angle_deg = rad_orientation*180/math.pi
    if new_angle_deg > 360:
        new_angle_deg = RoundTo15(abs(new_angle_deg - 360))
    
    new_node = Node((new_x, new_y), new_angle_deg, 0, ng , 0)
    curr_node = [(cnode.config[0],cnode.config[1]), cnode.angle, cnode.g, cnode.h, cnode.f]

    #print('move_135 node', new_node.config)
    if isSafe(new_x, new_y) == True: 
        return new_node
    else:
        return None
  
def move_90(cnode): # orientation):
    start_x = cnode.config[0]
    start_y = cnode.config[1]
    orientation = cnode.angle
    ng = cnode.g + math.sqrt(2)
 
    start_rad_orientation = (orientation*math.pi)/180
    start_rad_orientation_step = 45 #15
    rad_orientation = start_rad_orientation + (start_rad_orientation_step*2*math.pi)/180

    dx = math.cos(rad_orientation)*step_size 
    dy = math.sin(rad_orientation)*step_size  
    new_x = Round2Point5(start_x + dx)
    new_y = Round2Point5(start_y + dy)

    new_angle_deg = rad_orientation*180/math.pi
    if new_angle_deg > 360:
        new_angle_deg = RoundTo15(abs(new_angle_deg - 360))
    new_node = Node((new_x, new_y), new_angle_deg, 0, ng , 0) 
    curr_node = [(cnode.config[0],cnode.config[1]), cnode.angle, cnode.g, cnode.h , cnode.f]

    #print('move_90 node', new_node.config)
    if isSafe(new_x, new_y) == True: 
        return new_node
    else:
        return None
    
def move_45(cnode): #orientation):
    start_x = cnode.config[0]
    start_y = cnode.config[1]
    orientation = cnode.angle
    ng = cnode.g - 2 * math.sqrt(2)
 
    start_rad_orientation = (orientation*math.pi)/180
    start_rad_orientation_step = 45 #15
    rad_orientation = start_rad_orientation + (start_rad_orientation_step*math.pi)/180

    dx = math.cos(rad_orientation)*step_size 
    dy = math.sin(rad_orientation)*step_size 
    
    new_x = Round2Point5(start_x + dx)
    new_y = Round2Point5(start_y + dy)

    new_angle_deg = rad_orientation*180/math.pi
    if new_angle_deg > 360:
        new_angle_deg = RoundTo15(abs(new_angle_deg - 360))
    new_node = Node((new_x, new_y), new_angle_deg, 0, ng , 0)
    curr_node = [(cnode.config[0],cnode.config[1]), cnode.angle, cnode.g, cnode.h , cnode.f]
    
    #print('move_45 node', new_node.config)
    if isSafe(new_x, new_y) == True: 
        return new_node
    else:
        return None
    
def move_0(cnode): # orientation):
    start_x = cnode.config[0]
    start_y = cnode.config[1]
    orientation = cnode.angle
    ng = cnode.g 
 
    rad_orientation = (orientation*math.pi)/180
    start_rad_orientation_step = 45 #15

    dx = math.cos(rad_orientation)*step_size 
    dy = math.sin(rad_orientation)*step_size 
    
    new_x = Round2Point5(start_x + dx)
    new_y = Round2Point5(start_y + dy)

    new_angle_deg = rad_orientation*180/math.pi
    if new_angle_deg > 360:
        new_angle_deg = RoundTo15(abs(new_angle_deg - 360))
    new_node = Node((new_x, new_y), new_angle_deg, 0, ng , 0)
    
    curr_node = [(cnode.config[0],cnode.config[1]), cnode.angle, cnode.g, cnode.h , cnode.f]
    
    #print('move_0 node', new_node.config)
    if isSafe(new_x, new_y) == True: 
        return new_node
    else:
        return None

# Saving the parent-child details         
class Node(object):

    def __init__(self, config, angle, h, g=1000000, f=1000000):
        self.config = config
        self.angle = angle
        #self.rate = 0
        self.h = h
        self.g = g
        self.f = f
        self.closed = False
        self.open = True
        self.children = []
        self.parent = None
        
        
    def add_child(self, obj):
        self.children.append(obj)
        obj.parent = self
    
    def __eq__(self, other):
        if self is None:
            return False
        if other is None:
            return False
        else:
            return self.config == other.config
        
    
    def __repr__(self):
      return f"{self.config} {self.angle} - h: {self.h} g: {self.g}  f: {self.f} "
    
    # defining less than for purposes of heap queue
    def __lt__(self, other):
      return self.f < other.f
    
    # defining greater than for purposes of heap queue
    def __gt__(self, other):
      return self.f > other.f

def find_path (cn):
    path = []
    
    empty_list = []
    vector_list = []
    #cn = goal_node
    while cn.config != initial_coordinate:
        child = cn.config 
        vec = [child] + [cn.angle] + [cn.h] + [cn.g] + [cn.f]
        vector_list.append(vec)
        #print('vector list', vector_list)

        empty_list.append(cn.config)
        cn = cn.parent
        #print('node config', cn.config)
        cv2.line(robot_world, tuple(cn.config), child, (200,0, 200), 1)
    print('Length of path', len(vector_list))
    return vector_list

def astar(initial_coordinate, initial_orientation):
    """Returns a list of tuples as a path from the given start to the given end in the given maze"""
    
    # Create start and end node
    start_node = Node(initial_coordinate, initial_orientation, 0,0,0)

    # Sub-function for goal
    def is_goal(loc):
            if dist(loc,final_coordinate) <= 1.5 + radius/2 + clearance:
                print("\nReached the Goal!")
                return loc
            else:
                return None
            
    if is_goal(initial_coordinate):
        return [initial_coordinate]
        
    # Initialize both open and closed list
    open_list = []
    closed_list = []
    
    # Add the start node to the open list
    open_list.append(start_node)
        
    # Adding a stop condition
    outer_iterations = 0
    max_iterations = 164 * 240 //2 # (len(maze[0]) * len(maze) // 2) to update
    
    
    while len(open_list) > 0:
        outer_iterations += 1
        
        # Get the current node
        current_node = open_list.pop()
        closed_list.append(current_node)
        
        if is_goal(current_node.config):
            print("\nGoal path:", find_path(current_node))   ##check find_path function
            
            return True
        
        if outer_iterations > max_iterations:
            # if we hit this point return the path such as it is
            # it will not contain the destination
            print('Too many iterations. Giving up on finding the path')
            return find_path(current_node)
    
        movements = [move_180(current_node), move_135(current_node), move_90(current_node),
                    move_45(current_node), move_0(current_node)]
                                                                             
        #print('moving', movements)
        
        # Generate children
        children = []
        child_node = []
        
        for next_node in movements:
            # Check if movement is possible
            if next_node == None:
                continue

            # Get node position and orientation
            next_position = next_node.config
                            #(next_node[0][0], next_node[0][1]) #next_node.config[0], 
                            #current_node.config[1])#+ next_node.config[1])
            
            next_orientation = next_node.angle #next_node[1] ## or should it be set back to zero
            next_g = next_node.g #[3]
            
            # Create new node
            n_node = Node(next_position, next_orientation,0,next_g,0)
            
            children.append(n_node)
        
        for child in children:
            # Child is on the closed list
            if len([closed_child for closed_child in closed_list if closed_child == child]) > 0:
                continue
               
            # Values of f, g and h
            child.h = aplha * child.g + beta * dist(child.config, final_coordinate)
            child.f = child.g + child.h
            '''print('ggg', child.g)
            print('hhh', child.h)
            print('fff', child.f)'''
            
            # Child is already in open list
            index = None
            for i in range(0, len(open_list)):
                if child.config == open_list[i].config:
                    index = i
                    break
            
            if index:
                if child.g >= open_list[index].g:
                    continue
                else:
                    open_list[index] = open_list[-1]
                    open_list.pop()
                    if index < len(open_list):
                        heapq._siftup(open_list, index)
                        heapq._siftdown_max(open_list, 0, index)
                        
            # Add the child to the open list
            open_list.insert(0, child)
            child.parent = current_node
            
            cv2.line(robot_world, tuple(child.parent.config), child.config, (255, 255, 0), 1)
            cv2.imshow('Visual', robot_world)
            cv2.waitKey(1)
            
    print('outer_iterations',outer_iterations)
    return             
           
goal_node = 0
if np.all(robot_world[initial_coordinate[1],
        initial_coordinate[0]] == [0, 0, 0]) or np.all(robot_world[final_coordinate[1],
        final_coordinate[0]] == [0, 0, 0]):
    print('Can not be placed on the obstacle')
else:
   __name__ == '__main__'           
   goal_node = astar(initial_coordinate, initial_orientation)

cv2.circle(robot_world, (80,30), 2, (255,255,0), -1)
cv2.circle(robot_world, (170,130), 2, (255,255,0), -1)
cv2.imshow('Marine Map', robot_world)
cv2.waitKey(0)
cv2.destroyAllWindows()  
    
end_time = datetime.now()
time_taken = end_time - start_time
print("Time taken to reach the Goal: ", time_taken) 