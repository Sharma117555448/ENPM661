# -*- coding: utf-8 -*-
"""
Created on Sun May  9 20:50:33 2021

@author: sharm
"""

# -*- coding: utf-8 -*-
"""
Created on Mon May  3 19:50:23 2021

@author: sharm
"""
### converting the map from Google maps oo workspace for the Path planning

import cv2
import math
import numpy as np
import heapq
from datetime import datetime

image2 = cv2.imread('test_new.jfif')
cv2.imshow('Map', image2)
image = cv2.imread('test_new.jfif', 0)
print(image.shape)
 
grid = np.ones((7,7), np.uint8)

ret, bw_img = cv2.threshold(image,180,255,cv2.THRESH_BINARY)
cv2.imshow("Binary Map",bw_img)

img_erosion = cv2.erode(bw_img, grid, iterations=1)

cv2.imshow('Input', image)
cv2.imshow('Rough Map', img_erosion)

img_half = cv2.resize(img_erosion, (0, 0), fx=0.2, fy=0.2)
print(img_half.shape)

cv2.imshow('Resized Map', img_half)
'''
import cv2

img = cv2.imread("testudo.png")
GRID_SIZE = 20

height, width, channels = img.shape
for x in range(0, width -1, GRID_SIZE):
     cv2.line(img, (x, 0), (x, height), (255, 0, 0), 1, 1)

cv2.imshow('Hehe', img)
key = cv2.waitKey(0)'''
#cv2.imshow('Map', image)
cv2.waitKey(0)
cv2.destroyAllWindows()