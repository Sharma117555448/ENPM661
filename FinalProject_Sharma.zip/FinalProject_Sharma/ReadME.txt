------ Final Project ----------
ENPM661				
Charu Sharma			
117555448			
charu107@umd.edu		
-------------------------------------
python: 3.0
IDE used : Spyder


The code runs on A star algorithm and executes the path for the robot to travel through the obstacles to reach 
the goal position. 


Files in the package:
1. test_new.jfif: is the image from google maps that is used as the workspace for the path planning
2. new_map.png: is the image which is converted and resized so as to be used efficiently
3. Map2img.py: python code to convert the test_new.jfif image to new_map.png
4. Astar_final_sharma.py: python code for performing the Astar path planning according to the parameters 
set in the paper
5. Improved_Astar_final_sharma.py : python code for the Improved A star path planning method.


Libraries used- matplotlib, numpy, pygame, heapq, time-These libraries are used to calculate the optimum path.

Just running the code in any IDE should work. Just make sure the images are in the same folder as the code files.

NOTE: Start and end goal are set as of now but can be changed with minor change in the code. 
